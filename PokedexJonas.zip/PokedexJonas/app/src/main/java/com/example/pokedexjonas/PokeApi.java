package com.example.pokedexjonas;

import android.net.Uri;

import java.io.IOException;

public class PokeApi {
    private final String apiurl="https://pokeapi.co/api/v2";
    String getNames(String names){
        Uri builtUri=Uri.parse(apiurl)
                .buildUpon()
                .appendPath("pokemon")
                .appendQueryParameter("limit","20")
                .build();
        String url=builtUri.toString();
        return doCall(url);
    }

    private String doCall(String url) {
        try {
            String JsonResponse = HttpUtils.get(url);
            return JsonResponse;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

